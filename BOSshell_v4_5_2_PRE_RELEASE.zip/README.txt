BOSshell version 4.5.2 for TI-84+CE
by beckadamtheinventor
August 30 / 2018

ABOUT:
This program is not meant to replace other shells, like Cesium (by MateoConLechuga); this shell cannot run programs at the moment. It currently only uses appvars for files; however, these appvars can have specific file types, in a system that is entirely seperate from the variable type.
This shell is still very much still in development, but this build is still functional, and has vary fe crash bugs. If you do encounter a bug or crash, please report it to me on Cemetech via PM or the Forum.


CREDITS:
Thank you to all the folks at Cemetech!
A special thanks to jcgter777 for his ongoing support! (and reminding me to work on this)
Thanks to LAX18 for baing the competition, as well as sharing code with me and vice versa.
A super special thanks to KermMartian, for Doors; which was the inspiration for BOSshell.
Seriously, thank you all! :)
-beckadamtheinventor


INSTALLATION:
Send "BOSSHELL.8xp" and "BOSdata.8xv" to your CE using TI-Connect or TILP. Select the program from the [prgm] list, then press [enter] to run it. The shell will load momentarily! :D


USAGE:
When the desktop appears, there will be a cursor, which you can move around with the arrow keys.
Right-click with [alpha] or [graph] to open the file menu; text will appear at the cursor position. From there, select a menu option using the left-right arrow keys and [2nd] or [trace].
Each item in this menu does something different.
<new> create a new file
This will show a second menu. From there, select a file type (see FILE TYPES for more details)
<open> open the file, which is hovered over by the cursor
NOTE: Not yet implemented
<edit> edit the file, which is hovered over by the cursor
NOTE: Only works with ".ximg" files right now.
<copy> Copy file
<paste> Paste file
Prompts for a file name (pasted file name)
<delete> Delete file (will delete from the calculator)
<cut> Cut file
NOTE: Not yet implemented (this works, but then "paste" does nothing)
<import> Add file to filesystem
Prompts for a file name (file to import)
<remove> Remove selected file from the filesystem
NOTE: This does not hide the file
<rename> Rename file
Prompts for a file name (new name)
<info> Show file info
Left-click on the icon in the bottom-left corner of the screen, and the version info will appear.
Right-click on that icon to open the settings menu.
Left-click over top of a file with [2nd] or [trace] to open it.


FILE TYPES:
text - has no editor at this time; text and formatted text document
ximg - see below for editor instructions; xlib color image (8bpp)
link - has no editor at this time; this type will act as a directory link
dmmx - has no editor at this time; this type will be similar to a matrix in the TI-OS


IMAGE EDITOR:
use arrow keys to move the box (selected pixel)
use [2nd] or [trace] to put a pixel to the screen using the current position and color
use [alpha] or [graph] to get the currently selected pixel color
use [y=] to choose a new color, then use arrow keys to select it (up/down +1/-1, right/left +16/-16)
use [window] to fill a rectangle with the current color from the current position to the next pixel selected
use [mode] to save the file
use [clear] to quit the editor
NOTE: quitting does not save the file


SETTINGS MENU:
<backgd> set background color
<text A> set text color A; used for non-inverted text
<text B> set text color B; used for inverted text background
<text C> set text color C; used for inverted text foreground


CHANGELOG:
-4.5.2: pre-release (Aug 30 / 2018)